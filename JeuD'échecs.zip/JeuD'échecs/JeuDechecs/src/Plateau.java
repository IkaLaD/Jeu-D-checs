public class Plateau {

    public static int[][] initPlateauVide() {
        int[][] plateau = new int[8][8];
        return plateau;
    }
    public static int[][] initPlateau(){

        int[][] plateau = new int[8][8];
        // Pion noir : 1
        // Tour noire : 3
        // Cavalier noir : 5
        // Reine noire : 7
        // Roi noir : 9
        // Fou noir : 11
        // Pion blanc : 2
        // Tour blanche : 4
        // Cavalier blanc : 6
        // Reine blanche : 8
        // Roi blanc : 10
        // Fou blanc : 12

        for(int i = 0 ; i < 8 ; i++) { // pion
            plateau[1][i] = 1;
            plateau[6][i] = 2;
        }
        for(int i = 0 ; i < 8 ; i+=7){ // tour
            plateau[0][i]=3;
            plateau[7][i]=4;
        }
        for(int i = 1 ; i < 7 ; i+=5){ // cavalier
            plateau[0][i]=5;
            plateau[7][i]=6;
        }
        for(int i = 2 ; i < 6 ; i+=3){ // fou
            plateau[0][i]=11;
            plateau[7][i]=12;
        }
        plateau[0][3]=7;
        plateau[0][4]=9;
        plateau[7][3]=8;
        plateau[7][4]=10;

    return plateau;
    }

    public static void afficherPlateau(int[][] plateau, int couleur){
        int cpt = couleur == 0 ? 0 : plateau.length-1;
        String couleurpion;
        String reset = "\u001B[0m";
        char lettre = couleur == 0 ? 'a' : 'h';
        int plusoumoins = couleur == 0 ? 1 : -1;
        System.out.print(" ㅤ");
        for(int i = 0 ; i < plateau.length ; i++)
        {
            System.out.print(lettre+" ㅤ");
            lettre+=plusoumoins;
        }
        System.out.println();
        for(int i = 0 ; i < plateau.length ; i++){
            System.out.print((Math.abs(cpt-i)+1)+" ");
            for(int j = 0 ; j < plateau[i].length ; j++){
                couleurpion = plateau[Math.abs(cpt-i)][Math.abs(cpt-j)]%2 == 0 ? "\u001B[30m" : "\u001B[37m";
                System.out.print(couleurpion+" ");
                switch(plateau[Math.abs(cpt-i)][Math.abs(cpt-j)])
                {
                    case 2:
                        System.out.print("♟");
                        break;
                    case 1:
                        System.out.print("♟");
                        break;
                    case 4:
                        System.out.print("♜");
                        break;
                    case 3:
                        System.out.print("♜");
                        break;
                    case 6:
                        System.out.print("♞");
                        break;
                    case 5:
                        System.out.print("♞");
                        break;
                    case 8:
                        System.out.print("♛");
                        break;
                    case 7:
                        System.out.print("♛");
                        break;
                    case 10:
                        System.out.print("♚");
                        break;
                    case 9:
                        System.out.print("♚");
                        break;
                    case 12:
                        System.out.print("♝");
                        break;
                    case 11:
                        System.out.print("♝");
                        break;
                    default:
                        System.out.print(reset+"▱");
                        break;
                }
                System.out.print(" "+reset);
            }
            System.out.println();
        }
    }
}
