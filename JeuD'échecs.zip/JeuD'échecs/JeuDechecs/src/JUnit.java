import org.junit.Test;

import java.sql.SQLOutput;

import static org.junit.jupiter.api.Assertions.*;

public class JUnit {

    @Test
    public final void deplacementFouLogique()
    {
        int[][] plateau1 = {
                {12,0,0,0,0,0,0,0},
                {1,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };

        assertTrue(Fonction.deplacementFouValide(plateau1, new Case(0, 0), new Case(7,7)));
        //Sans obstacle

        int[][] plateau2 = {
                {12,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,5,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };

        assertFalse(Fonction.deplacementFouValide(plateau2, new Case(0, 0), new Case(7,7)));
        //Avec obstacle ennemi

        int[][] plateau3 = {
                {12,0,0,0,0,0,0,0},
                {1,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,6,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };

        assertFalse(Fonction.deplacementFouValide(plateau3, new Case(0, 0), new Case(7,7)));
        //Avec obstacle allié
    }

    @Test
    public final void deplacementTourLogique()
    {
        int[][] plateau1 = {
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,3,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };

        assertTrue(Fonction.deplacementTourValide(plateau1, new Case(3, 3), new Case(3,0)));
        //Sans obstacle

        int[][] plateau2 = {
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,3,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };

        assertTrue(Fonction.deplacementTourValide(plateau2, new Case(3, 3), new Case(3,7)));
        //Sans obstacle

        int[][] plateau3 = {
                {0,0,0,0,0,0,0,0},
                {0,0,0,2,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,3,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };

        assertFalse(Fonction.deplacementTourValide(plateau3, new Case(3, 3), new Case(3,0)));
        //Avec obstacle

        int[][] plateau4 = {
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,3,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,2,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };

        assertFalse(Fonction.deplacementTourValide(plateau4, new Case(3, 3), new Case(3,7)));
        //Avec obstacle
    }

    @Test
    public final void deplacementReineLogique()
    {
        int[][] plateau1 = {
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,8,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };

        assertTrue(Fonction.deplacementReineValide(plateau1, new Case(3, 3), new Case(0,0)));
        //Sans obstacle

        int[][] plateau2 = {
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,8,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };

        assertTrue(Fonction.deplacementReineValide(plateau2, new Case(3, 3), new Case(3,1)));
        //Sans obstacle

        int[][] plateau3 = {
                {0,0,0,0,0,0,0,0},
                {0,0,0,2,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,8,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };

        assertFalse(Fonction.deplacementReineValide(plateau3, new Case(3, 3), new Case(3,0)));
        //Avec obstacle

        int[][] plateau4 = {
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,2,0,0,0},
                {0,0,0,3,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };

        assertFalse(Fonction.deplacementReineValide(plateau4, new Case(3, 3), new Case(7,0)));
        //Avec obstacle
    }

    @Test
    public final void caseControleesParPion()
    {
        // Bordure + ligne pion
        int[][] plateau1 = {
                {0,0,0,0,0,0,0,0},
                {1,0,0,0,0,0,0,0},
                {0,2,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControleesAttendu1 = {
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {1,1,0,0,0,0,0,0},
                {1,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControlees1 = Fonction.actualisationCaseControlees(plateau1, 1);

        // ligne pion du départ jeu
        int[][] plateau2 = {
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,1,0,0,0,0,0},
                {0,0,2,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControleesAttendu2 = {
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,2,0,0,0,0,0},
                {0,2,2,2,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControlees2 = Fonction.actualisationCaseControlees(plateau2, 0);

        // Pas sur la ligne pion du départ jeu
        int[][] plateau3 = {
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,1,0,0,0,0,0},
                {0,2,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControleesAttendu3 = {
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,1,1,1,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControlees3 = Fonction.actualisationCaseControlees(plateau3, 1);

        for(int i = 0 ; i < plateau1.length ; i++)
        {
            for(int j = 0 ; j < plateau1[i].length ; j++)
            {
                assertEquals(caseControlees1[i][j], caseControleesAttendu1[i][j]);
                assertEquals(caseControlees2[i][j], caseControleesAttendu2[i][j]);
                assertEquals(caseControlees3[i][j], caseControleesAttendu3[i][j]);
            }
        }
    }

    @Test
    public final void caseControleesParTour()
    {
        // Sans obstacles
        int[][] plateau1 = {
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,3,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControleesAttendu1 = {
                {0,0,0,1,0,0,0,0},
                {0,0,0,1,0,0,0,0},
                {1,1,1,0,1,1,1,1},
                {0,0,0,1,0,0,0,0},
                {0,0,0,1,0,0,0,0},
                {0,0,0,1,0,0,0,0},
                {0,0,0,1,0,0,0,0},
                {0,0,0,1,0,0,0,0}
        };
        int[][] caseControlees1 = Fonction.actualisationCaseControlees(plateau1, 1);

        // Avec obstacles
        int[][] plateau2 = {
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,5,0,4,0,0,5,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,5,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControleesAttendu2 = {
                {0,0,0,2,0,0,0,0},
                {0,0,0,2,0,0,0,0},
                {0,2,2,0,2,2,2,0},
                {0,0,0,2,0,0,0,0},
                {0,0,0,2,0,0,0,0},
                {0,0,0,2,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControlees2 = Fonction.actualisationCaseControlees(plateau2, 0);

        for(int i = 0 ; i < plateau1.length ; i++)
        {
            for(int j = 0 ; j < plateau1[i].length ; j++)
            {
                assertEquals(caseControlees1[i][j], caseControleesAttendu1[i][j]);
                assertEquals(caseControlees2[i][j], caseControleesAttendu2[i][j]);
            }
        }
    }

    @Test
    public final void caseControleesParCavalier() {
        // Toutes les cases controlées sur le plateau
        int[][] plateau1 = {
                {0, 0, 2, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 5, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0}
        };
        int[][] caseControleesAttendu1 = {
                {0, 0, 1, 0, 1, 0, 0, 0},
                {0, 1, 0, 0, 0, 1, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0},
                {0, 1, 0, 0, 0, 1, 0, 0},
                {0, 0, 1, 0, 1, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0}
        };
        int[][] caseControlees1 = Fonction.actualisationCaseControlees(plateau1, 1);

        // Pas toutes les cases controlées sur le plateau
        int[][] plateau2 = {
                {0, 0, 0, 0, 0, 0, 0, 0},
                {0, 6, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 1, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0}
        };
        int[][] caseControleesAttendu2 = {
                {0, 0, 0, 2, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 2, 0, 0, 0, 0},
                {2, 0, 2, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0}
        };
        int[][] caseControlees2 = Fonction.actualisationCaseControlees(plateau2, 0);

        for (int i = 0; i < plateau1.length; i++) {
            for (int j = 0; j < plateau1[i].length; j++) {
                assertEquals(caseControlees1[i][j], caseControleesAttendu1[i][j]);
                assertEquals(caseControlees2[i][j], caseControleesAttendu2[i][j]);
            }
        }
    }

    @Test
    public final void caseControleesParFou()
    {
        // Sans obstacles
        int[][] plateau1 = {
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,11,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControleesAttendu1 = {
                {0,1,0,0,0,1,0,0},
                {0,0,1,0,1,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,1,0,1,0,0,0},
                {0,1,0,0,0,1,0,0},
                {1,0,0,0,0,0,1,0},
                {0,0,0,0,0,0,0,1},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControlees1 = Fonction.actualisationCaseControlees(plateau1, 1);

        // Pas toutes les cases controlées sur le plateau
        int[][] plateau2 = {
                {0,0,0,0,0,0,0,0},
                {0,0,1,0,5,0,0,0},
                {0,0,0,12,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,7,0,0,0,0,0,0},
                {0,0,0,0,0,0,5,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControleesAttendu2 = {
                {0,0,0,0,0,0,0,0},
                {0,0,2,0,2,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,2,0,2,0,0,0},
                {0,2,0,0,0,2,0,0},
                {0,0,0,0,0,0,2,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControlees2 = Fonction.actualisationCaseControlees(plateau2, 0);

        for(int i = 0 ; i < plateau1.length ; i++)
        {
            for(int j = 0 ; j < plateau1[i].length ; j++)
            {
                assertEquals(caseControlees1[i][j], caseControleesAttendu1[i][j]);
                assertEquals(caseControlees2[i][j], caseControleesAttendu2[i][j]);
            }
        }
    }

    @Test
    public final void caseControleesParReine()
    {
        // Sans obstacles
        int[][] plateau1 = {
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,7,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControleesAttendu1 = {
                {0,1,0,1,0,1,0,0},
                {0,0,1,1,1,0,0,0},
                {1,1,1,0,1,1,1,1},
                {0,0,1,1,1,0,0,0},
                {0,1,0,1,0,1,0,0},
                {1,0,0,1,0,0,1,0},
                {0,0,0,1,0,0,0,1},
                {0,0,0,1,0,0,0,0}
        };
        int[][] caseControlees1 = Fonction.actualisationCaseControlees(plateau1, 1);

        // Pas toutes les cases controlées sur le plateau
        int[][] plateau2 = {
                {0,0,0,0,0,0,0,0},
                {0,0,1,0,5,0,0,0},
                {0,0,0,8,0,5,0,0},
                {0,0,0,0,0,0,0,0},
                {0,7,0,0,0,0,0,0},
                {0,0,0,5,0,0,5,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControleesAttendu2 = {
                {0,0,0,2,0,0,0,0},
                {0,0,2,2,2,0,0,0},
                {2,2,2,0,2,2,0,0},
                {0,0,2,2,2,0,0,0},
                {0,2,0,2,0,2,0,0},
                {0,0,0,2,0,0,2,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControlees2 = Fonction.actualisationCaseControlees(plateau2, 0);

        for(int i = 0 ; i < plateau1.length ; i++)
        {
            for(int j = 0 ; j < plateau1[i].length ; j++)
            {
                assertEquals(caseControlees1[i][j], caseControleesAttendu1[i][j]);
                assertEquals(caseControlees2[i][j], caseControleesAttendu2[i][j]);
            }
        }
    }

    @Test
    public final void caseControleesParRoi()
    {
        // Sans obstacles
        int[][] plateau1 = {
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,9,0,0,0,0},
                {0,0,0,0,2,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControleesAttendu1 = {
                {0,0,0,0,0,0,0,0},
                {0,0,1,1,1,0,0,0},
                {0,0,1,0,1,0,0,0},
                {0,0,1,1,1,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControlees1 = Fonction.actualisationCaseControlees(plateau1, 1);

        // Pas toutes les cases controlées sur le plateau
        int[][] plateau2 = {
                {0,0,0,10,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControleesAttendu2 = {
                {0,0,2,0,2,0,0,0},
                {0,0,2,2,2,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
        };
        int[][] caseControlees2 = Fonction.actualisationCaseControlees(plateau2, 0);

        for(int i = 0 ; i < plateau1.length ; i++)
        {
            for(int j = 0 ; j < plateau1[i].length ; j++)
            {
                assertEquals(caseControlees1[i][j], caseControleesAttendu1[i][j]);
                assertEquals(caseControlees2[i][j], caseControleesAttendu2[i][j]);
            }
        }
    }
}
