import java.util.Scanner;

public class DeroulePartie {

    public static void main(String args[]){
        int[][] plateaujeu = Plateau.initPlateau();
        int[][] caseControleesParNoir = Fonction.actualisationCaseControlees(plateaujeu, 1);
        int[][] caseControleesParBlanc = Fonction.actualisationCaseControlees(plateaujeu, 0);

        while(!Fonction.estEnEchecEtMat(plateaujeu, caseControleesParBlanc, caseControleesParNoir, 1) && !Fonction.estEnEchecEtMat(plateaujeu, caseControleesParNoir, caseControleesParBlanc,0))
        {
            for(int couleur = 0 ; couleur <= 1 ; couleur++)
            {
                // Vérifie si le roi est en échec et stock l'information (pour ne plus pouvoir roque)
                if(Fonction.estEnEchec(plateaujeu, caseControleesParNoir, 0))
                {
                    System.out.println("Votre roi est menacé ! Vous êtes obligé de parrer l'échec.");
                    Fonction.roquePossibleBlanc[0]=false;
                }
                if(Fonction.estEnEchec(plateaujeu, caseControleesParBlanc, 1))
                {
                    System.out.println("Votre roi est menacé ! Vous êtes obligé de parrer l'échec.");
                    Fonction.roquePossibleNoir[0]=false;
                }

                Plateau.afficherPlateau(plateaujeu, couleur);

                boolean mouvementvalide=false;
                do
                {
                    System.out.print("Pion : ");
                    Case debut = saisieCoordonnees();
                    if(Fonction.retournerPion(plateaujeu, debut)%2!=couleur || Fonction.vide(plateaujeu, debut)) {
                        continue;
                    }
                    System.out.print("Déplacement : ");
                    Case fin = saisieCoordonnees();

                    if(couleur==0)
                        mouvementvalide = Fonction.deplacementValide(plateaujeu, caseControleesParNoir, debut, fin);
                    else
                        mouvementvalide = Fonction.deplacementValide(plateaujeu, caseControleesParBlanc, debut, fin);

                    if(mouvementvalide)
                        Fonction.deplacerPiece(plateaujeu, debut, fin);


                }while(!mouvementvalide);

                caseControleesParBlanc = Fonction.actualisationCaseControlees(plateaujeu, 0);
                caseControleesParNoir = Fonction.actualisationCaseControlees(plateaujeu, 1);
            }
        }

        if(Fonction.estEnEchecEtMat(plateaujeu, caseControleesParBlanc, caseControleesParNoir, 1))
        {
            Plateau.afficherPlateau(plateaujeu, 0);
            System.out.println("Les noirs on gagnés par échecs et mat ! ");
        }
        else
        {
            Plateau.afficherPlateau(plateaujeu, 1);
            System.out.println("Les blanc on gagnés par échecs et mat ! ");
        }
    }

    public static Case saisieCoordonnees()
    {
        Scanner sc = new Scanner(System.in);
        String coordonnees;

        int ligne=0;
        int colonne=0;
        boolean saisieValide;

        do
        {
            saisieValide=false;
            System.out.println("Saisissez les coordonnées.");
            coordonnees = sc.nextLine().toLowerCase();

            if(coordonnees.length()==2)
            {
                if (coordonnees.charAt(0) > 96 && coordonnees.charAt(0) < 105 && coordonnees.charAt(1) > 48 && coordonnees.charAt(1) < 57)
                {
                    ligne = Character.getNumericValue(coordonnees.charAt(1))-1;
                    colonne = coordonnees.charAt(0)-97;
                    saisieValide=true;
                }
                else if (coordonnees.charAt(0) > 48 && coordonnees.charAt(0) < 57 && coordonnees.charAt(1) > 96 && coordonnees.charAt(1) < 105)
                {
                    ligne = Character.getNumericValue(coordonnees.charAt(0))-1;
                    colonne = coordonnees.charAt(1)-97;
                    saisieValide=true;
                }
            }
            if(colonne<0 || colonne > 7 || ligne < 0 || ligne > 7)
                saisieValide=false;

        }while(!saisieValide );

        return new Case(colonne, ligne);
    }
}
