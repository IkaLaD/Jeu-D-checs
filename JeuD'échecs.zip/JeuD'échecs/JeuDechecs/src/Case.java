public class Case
{
    private int colonne, ligne;
    public Case(int colonne,int ligne)
    {
        this.colonne = colonne;
        this.ligne = ligne;
    }

    public int getColonne() {
        return colonne;
    }

    public int getLigne() {
        return ligne;
    }
}
