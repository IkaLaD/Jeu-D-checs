import java.util.ArrayList;
import java.util.List;

public class Fonction {

    public static boolean[] roquePossibleBlanc = {true,true,true}; // Permet de valider ou non le roque du roi
    public static boolean[] roquePossibleNoir = {true,true,true}; // Permet de valider ou non le roque du roi
    public static List<Integer> pionBlancPris = new ArrayList<>(); // Pion manger par les noir
    public static List<Integer> pionNoirPris = new ArrayList<>(); // Pion manger par les blanc

    /***
     *
     * @param plateau
     * @param debut
     * @param fin
     *
     * Vérifie si le déplacement de la pièce qui à été sélectionné est valide
     */
    public static boolean deplacementValide(int[][] plateau, int[][] caseControleesParEnnemi, Case debut, Case fin)
    {
        boolean deplacementValide;
        boolean enEchec;
        int pion = plateau[debut.getLigne()][debut.getColonne()];
        int couleurennemi = pion%2 == 0 ? 1 : 0;

        if(pion <= 2)
            deplacementValide = deplacementPionValide(plateau, debut, fin);
        else if(pion <= 4)
            deplacementValide = deplacementTourValide(plateau, debut, fin);
        else if(pion <= 6)
            deplacementValide = deplacementCavalierValide(plateau, debut, fin);
        else if(pion <= 8)
            deplacementValide = deplacementReineValide(plateau, debut, fin);
        else if(pion <= 10)
            deplacementValide = deplacementRoiValide(plateau, caseControleesParEnnemi, debut, fin);
        else
            deplacementValide = deplacementFouValide(plateau, debut, fin);


        int[][] plateautemp = copie(plateau);
        plateautemp[debut.getLigne()][debut.getColonne()]=0;
        plateautemp[fin.getLigne()][fin.getColonne()]=pion;
        int[][] caseControleestemp = actualisationCaseControlees(plateautemp, couleurennemi);

        enEchec = estEnEchec(plateautemp, caseControleestemp, pion%2);



        return deplacementValide && !enEchec;
    }

    /***
     *
     * @param plateau
     * @param debut
     * @param fin
     *
     * Vérifie si le mouvement saisie pour un pion est logique (pas de en passant)
     */
    public static boolean deplacementPionValide(int[][] plateau, Case debut, Case fin)
    {
        int directionY = plateau[debut.getLigne()][debut.getColonne()]%2 == 0 ? -1 : 1;
        int lignepion = plateau[debut.getLigne()][debut.getColonne()]%2 == 0 ? 6 : 1;

        if(debutFinMemeCouleur(plateau, debut, fin))
            return false;
        if(vide(plateau, fin))
        {
            if(debut.getColonne()==fin.getColonne())
            {
                if (fin.getLigne() - debut.getLigne() == directionY)
                    return true;
                if (fin.getLigne()-debut.getLigne() == (directionY * 2) && debut.getLigne() == lignepion && vide(plateau, new Case(fin.getColonne(), fin.getLigne()-directionY)))
                    return true;
            }
            return false;
        }
        else
        {
            if(Math.abs(debut.getColonne()-fin.getColonne())==1 && fin.getLigne()-debut.getLigne()==directionY)
                return true;
            return false;
        }
    }

    /***
     *
     * @param plateau
     * @param debut
     * @param fin
     *
     * Vérifie si le mouvement saisie pour un cavalier est logique
     */
    public static boolean deplacementCavalierValide(int[][] plateau, Case debut, Case fin) {
        int debutX = debut.getColonne(), finX = fin.getColonne();
        int debutY = debut.getLigne(), finY = fin.getLigne();

        if (!debutFinMemeCouleur(plateau, debut, fin))
        {
            for (int i = -2; i <= 2; i += 4) {
                for (int j = -1; j <= 1; j += 2) {
                    if (!debutFinMemeCouleur(plateau, debut, new Case(finX, finY))) {
                        if (debutX + j == finX && debutY + i == finY)
                            return true;
                        if (debutX + i == finX && debutY + j == finY)
                            return true;
                    }
                }
            }
        }
        return false;
    }

    /***
     *
     * @param plateau
     * @param debut
     * @param fin
     *
     * Vérifie si le mouvement saisie pour un fou est logique
     */
    public static boolean deplacementFouValide(int[][] plateau, Case debut, Case fin) {
        int colonne = debut.getColonne();
        int ligne = debut.getLigne();

        if (!debutFinMemeCouleur(plateau, debut, fin))
        {
            for (int i = -1; i <= 1; i += 2) {
                for (int j = -1; j <= 1; j += 2) {
                    int cpt = 1;

                    while (coordonneesSurPlateau(colonne + (cpt * i), ligne + (cpt * j))) {
                        if (colonne + (cpt * i) == fin.getColonne() && ligne + (cpt * j) == fin.getLigne())
                            return true;
                        if (!vide(plateau, new Case(colonne + (cpt * i), ligne + (cpt * j))))
                            cpt = 10;
                        cpt++;
                    }
                }
            }
        }
        return false;
    }

    /***
     *
     * @param plateau
     * @param debut
     * @param fin
     *
     * Vérifie si le mouvement saisie pour une tour est logique
     */
    public static boolean deplacementTourValide(int[][] plateau, Case debut, Case fin)
    {
        int debutColonne = debut.getColonne(),debutLigne = debut.getLigne();
        int finColonne = fin.getColonne(),finLigne = fin.getLigne();

        if((debutColonne==finColonne || debutLigne==finLigne ) && !debutFinMemeCouleur(plateau, debut, fin))
        {
            for (int i = -1; i <= 1; i += 2)
            {
                int cpt = 1;
                if (debutColonne == finColonne)
                {
                    while (coordonneesSurPlateau(debutColonne, (debutLigne+(cpt * i))))
                    {
                        if ((debutLigne+(cpt * i)) == finLigne)
                            return true;
                        if (!vide(plateau, debutColonne, debutLigne + (cpt * i)))
                            cpt=10;
                        cpt++;
                    }
                }
                else
                {
                    while (coordonneesSurPlateau((debutColonne + (cpt * i)), debutLigne))
                    {
                        if ((debutColonne + (cpt * i)) == finColonne)
                            return true;
                        if (!vide(plateau, (debutColonne + (cpt * i)), debutLigne))
                            cpt = 10;
                        cpt++;
                    }
                }
            }
        }
        return false;
    }

    /***
     *
     * @param plateau
     * @param debut
     * @param fin
     *
     * Vérifie si le mouvement saisie pour une reine est logique
     */
    public static boolean deplacementReineValide(int[][] plateau, Case debut, Case fin)
    {
        int debutColonne = debut.getColonne(),debutLigne = debut.getLigne();
        int finColonne = fin.getColonne(),finLigne = fin.getLigne();

        if(!debutFinMemeCouleur(plateau, debut, fin))
        {
            for (int i = -1; i <= 1; i++) {
                for (int j = -1; j <= 1; j++) {
                    if (i != 0 || j != 0) {
                        int cpt = 1;

                        while (coordonneesSurPlateau(debutLigne + (cpt * i), debutColonne + (cpt * j))) {
                            if ((debutLigne + (cpt * i) == finLigne && debutColonne + (cpt * j) == finColonne))
                                return true;
                            if (!vide(plateau, debutColonne + (cpt * j), debutLigne + (cpt * i)))
                                cpt = 10;
                            cpt++;
                        }
                    }
                }
            }
        }
        return false;
    }

    /***
     *
     * @param plateau
     * @param debut
     * @param fin
     *
     * Vérifie si le mouvement saisie pour un roi est logique (ne prend pas en compte le roque : voir autre méthode deplacementRoiRoqueValide)
     */
    public static boolean deplacementRoiValide(int[][] plateau, int[][] caseControleesParEnnemi, Case debut, Case fin)
    {
        int debutColonne = debut.getColonne(),debutLigne = debut.getLigne();
        int finColonne = fin.getColonne(),finLigne = fin.getLigne();
        int couleur = plateau[debutLigne][debutColonne]%2==0 ? 0 : 1;

        if(!debutFinMemeCouleur(plateau, debut, fin))
        {
            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    if ((debutColonne + i) == finColonne && (debutLigne + j) == finLigne && (i!=0 || j!=0))
                        if(caseControleesParEnnemi[debutLigne + j][debutColonne + i]!=1)
                            return true;
                }
            }
        }
        if(couleur==0)
            if(debut.getColonne() == 4 && debut.getLigne()==7)
                return roquePossible(plateau, couleur, fin, caseControleesParEnnemi);
        if(couleur==1)
            if(debut.getColonne() == 4 && debut.getLigne()==0)
                return roquePossible(plateau, couleur, fin, caseControleesParEnnemi);


        return false;
    }

    /***
     *
     * @param plateau
     * @param debut
     * @param fin
     *
     * effectue le déplacement du pion lorsque les vérifications on été faite au préalable
     */
    public static void deplacerPiece(int[][] plateau, Case debut, Case fin)
    {
        int debutX = debut.getColonne(),debutY = debut.getLigne();
        int finX = fin.getColonne(),finY = fin.getLigne();
        int pion = plateau[debutY][debutX];


        if(couleur(plateau, new Case(debutX, debutY))==0)
            pionBlancPris.add(plateau[debutY][debutX]);
        else
            pionNoirPris.add(plateau[debutY][debutX]);

        // Permet de savoir que le roi à aumoins bouger une fois et ne pourra pas roque
        if(pion==10)
            roquePossibleBlanc[0]=false;
        else if(pion==9)
            roquePossibleNoir[0]=false;
        else if(pion==4)
        {
            if(debut.getLigne()==7 && debut.getColonne()==0)
                roquePossibleBlanc[1]=false;
            else if(debut.getLigne()==7 && debut.getColonne()==7)
                roquePossibleBlanc[2]=false;
        }
        else if(pion==3)
        {
            if(debut.getLigne()==0 && debut.getColonne()==7)
                roquePossibleNoir[1]=false;
            else if(debut.getLigne()==0 && debut.getColonne()==0)
                roquePossibleNoir[2]=false;
        }

        plateau[debutY][debutX] = 0;
        plateau[finY][finX] = pion;
    }

    /***
     *
     * @param plateau
     * @param couleur
     *
     * Permet pour la couleur du pion sélectionné, d'actualiser les case qui sont controlées par les pions de cette couleur
     * Case controlées par les pions blanc : 2
     * Case controlées par les pions noir : 1
     */
    public static int[][] actualisationCaseControlees(int[][] plateau, int couleur)
    {
        int[][] plateauCaseControlees = new int[8][8];

        for(int i = 0 ; i < plateau.length ; i++)
        {
            for(int j = 0 ; j < plateau[i].length ; j++)
            {
                if(!vide(plateau, j, i) && plateau[i][j]%2==couleur)
                {
                    int pion = plateau[i][j];

                    if(pion <= 2)
                        plateauCaseControlees = controleCasePion(plateau, plateauCaseControlees, new Case(j,i), couleur);
                    else if(pion <= 4)
                        plateauCaseControlees = controleCaseTour(plateau, plateauCaseControlees, new Case(j,i), couleur);
                    else if(pion <= 6)
                        plateauCaseControlees = controleCaseCavalier(plateauCaseControlees, new Case(j,i), couleur);
                    else if(pion <= 8)
                        plateauCaseControlees = controleCaseReine(plateau, plateauCaseControlees, new Case(j,i), couleur);
                    else if(pion <= 10)
                        plateauCaseControlees = controleCaseRoi(plateauCaseControlees, new Case(j, i), couleur);
                    else
                        plateauCaseControlees = controleCaseFou(plateau, plateauCaseControlees, new Case(j,i), couleur);
                }
            }
        }

        return plateauCaseControlees;
    }

    /***
     *
     * @param plateau
     * @param plateauCaseControlees
     * @param piece
     * @param couleur
     *
     * Retourne les emplacement controlées par le pion sur la case piece
     */
    public static int[][] controleCasePion(int[][] plateau, int[][] plateauCaseControlees, Case piece, int couleur)
    {
        int couleurControlee = couleur == 0 ? 2 : 1;

        int directionY = plateau[piece.getLigne()][piece.getColonne()]%2 == 0 ? -1 : 1;

        // Les 3 cases controlées en face de lui (2 diagonales et en face)
        if(coordonneesSurPlateau(piece.getLigne() + directionY, piece.getColonne()))
            plateauCaseControlees[piece.getLigne() + directionY][piece.getColonne()] = couleurControlee;
        if(coordonneesSurPlateau(piece.getLigne()+ directionY, piece.getColonne()-1) && plateau[piece.getLigne()+ directionY][piece.getColonne()-1]!=0)
            plateauCaseControlees[piece.getLigne() + directionY][piece.getColonne()-1] = couleurControlee;
        if(coordonneesSurPlateau(piece.getLigne() + directionY, piece.getColonne()+1) && plateau[piece.getLigne()+ directionY][piece.getColonne()+1]!=0)
            plateauCaseControlees[piece.getLigne() + directionY][piece.getColonne()+1] = couleurControlee;

        return plateauCaseControlees;
    }

    /***
     *
     * @param plateau
     * @param plateauCaseControlees
     * @param piece
     * @param couleur
     *
     * Retourne les emplacement controlées par la tour sur la case piece
     */
    public static int[][] controleCaseTour(int[][] plateau, int[][] plateauCaseControlees, Case piece, int couleur)
    {
        int couleurControlee = couleur == 0 ? 2 : 1;
        int debutColonne=piece.getColonne();
        int debutLigne=piece.getLigne();

        for (int i = -1; i <= 1; i += 2)
        {
            int cpt = 1;
            while (coordonneesSurPlateau(debutColonne, (debutLigne+(cpt * i))) && vide(plateau, debutColonne, (debutLigne+(cpt * i))))
            {
                plateauCaseControlees[debutLigne+(cpt * i)][debutColonne]=couleurControlee;
                cpt++;
            }
            if(coordonneesSurPlateau(debutColonne, debutLigne+(cpt * i)))
                plateauCaseControlees[debutLigne+(cpt * i)][debutColonne]=couleurControlee;

            cpt=1;
            while (coordonneesSurPlateau((debutColonne + (cpt * i)), debutLigne) && vide(plateau, (debutColonne+(cpt * i)), (debutLigne)))
            {
                plateauCaseControlees[debutLigne][debutColonne+(cpt * i)]=couleurControlee;
                cpt++;
            }
            if(coordonneesSurPlateau(debutColonne+(cpt * i), debutLigne))
                plateauCaseControlees[debutLigne][debutColonne+(cpt * i)]=couleurControlee;
        }
        return plateauCaseControlees;
    }

    /***
     *
     * @param plateauCaseControlees
     * @param piece
     * @param couleur
     *
     * Retourne les emplacement controlées par le cavalier sur la case piece
     */
    public static int[][] controleCaseCavalier(int[][] plateauCaseControlees, Case piece, int couleur)
    {
        int couleurControlee = couleur == 0 ? 2 : 1;
        int pieceColonne = piece.getColonne();
        int pieceLigne = piece.getLigne();

            for (int i = -2; i <= 2; i += 4) {
                for (int j = -1; j <= 1; j += 2) {
                    if(coordonneesSurPlateau(pieceColonne+i, pieceLigne+j))
                        plateauCaseControlees[pieceLigne+j][pieceColonne+i] = couleurControlee;
                    if(coordonneesSurPlateau(pieceColonne+j, pieceLigne+i))
                        plateauCaseControlees[pieceLigne+i][pieceColonne+j] = couleurControlee;

                }
            }

        return plateauCaseControlees;
    }

    /***
     *
     * @param plateau
     * @param plateauCaseControlees
     * @param piece
     * @param couleur
     *
     * Retourne les emplacement controlées par le fou sur la case piece
     */
    public static int[][] controleCaseFou(int[][] plateau, int[][] plateauCaseControlees, Case piece, int couleur)
    {
        int couleurControlee = couleur == 0 ? 2 : 1;
        int pieceColonne = piece.getColonne();
        int pieceLigne = piece.getLigne();

        for (int i = -1; i <= 1; i += 2) {
            for (int j = -1; j <= 1; j += 2) {
                int cpt = 1;
                while (coordonneesSurPlateau(pieceColonne + (cpt * i), pieceLigne + (cpt * j)) && vide(plateau,pieceColonne + (cpt * i) ,pieceLigne + (cpt * j)))
                {
                    plateauCaseControlees[pieceLigne + (cpt * j)][pieceColonne + (cpt * i)]=couleurControlee;
                    cpt++;
                }
                if(coordonneesSurPlateau(pieceColonne + (cpt * i), pieceLigne + (cpt * j)))
                    plateauCaseControlees[pieceLigne + (cpt * j)][pieceColonne + (cpt * i)]=couleurControlee;
            }
        }
        return plateauCaseControlees;
    }

    /***
     *
     * @param plateau
     * @param plateauCaseControlees
     * @param piece
     * @param couleur
     *
     * Retourne les emplacement controlées par la reine sur la case piece
     */
    public static int[][] controleCaseReine(int[][] plateau, int[][] plateauCaseControlees, Case piece, int couleur)
    {
        int couleurControlee = couleur == 0 ? 2 : 1;
        int pieceColonne = piece.getColonne();
        int pieceLigne = piece.getLigne();

        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                if (i != 0 || j != 0) {
                    int cpt = 1;

                    while (coordonneesSurPlateau(pieceLigne + (cpt * i), pieceColonne + (cpt * j)) && vide(plateau, pieceColonne + (cpt * j), pieceLigne + (cpt * i))) {
                        plateauCaseControlees[pieceLigne + (cpt * i)][pieceColonne + (cpt * j)] = couleurControlee;
                        cpt++;
                    }
                    if(coordonneesSurPlateau(pieceLigne + (cpt * i), pieceColonne + (cpt * j)))
                        plateauCaseControlees[pieceLigne + (cpt * i)][pieceColonne + (cpt * j)] = couleurControlee;
                }
            }
        }

        return plateauCaseControlees;
    }

    /***
     *
     * @param plateauCaseControlees
     * @param piece
     * @param couleur
     *
     * Retourne les emplacement controlées par le roi sur la case piece
     */
    public static int[][] controleCaseRoi(int[][] plateauCaseControlees, Case piece, int couleur)
    {
        int couleurControlee = couleur == 0 ? 2 : 1;
        int pieceColonne = piece.getColonne();
        int pieceLigne = piece.getLigne();

        for (int i = -1; i <= 1; i++)
        {
            for (int j = -1; j <= 1; j++)
            {
                if(coordonneesSurPlateau(pieceColonne+i,pieceLigne+j) && (i!=0 || j!=0))
                    plateauCaseControlees[pieceLigne+j][pieceColonne+i]=couleurControlee;
            }
        }

        return plateauCaseControlees;
    }

    public static boolean estEnEchec(int[][] plateau, int[][] plateauCaseControlees, int couleur)
    {
        for(int i = 0 ; i < plateau.length ; i++)
        {
            for(int j = 0 ; j < plateau[i].length ; j++)
            {
                if((plateau[i][j]==9 || plateau[i][j]==10) && plateau[i][j]%2 == couleur && !vide(plateau, j, i) && plateauCaseControlees[i][j] != 0)
                    return true;
            }
        }
        return false;
    }

    public static boolean estEnEchecEtMat(int[][] plateau, int[][] plateauCaseControleesEnnemi, int[][] plateauCaseControleesAllie, int couleur)
    {
        int couleurControle = couleur == 0 ? 2 : 1;
        if(!estEnEchec(plateau, plateauCaseControleesEnnemi, couleur))
            return false;

        int roiColonne=-1;
        int roiLigne=-1;

        for(int i = 0 ; i < plateau.length ; i++)
        {
            for(int j = 0 ; j < plateau[i].length ; j++)
            {
                if(plateau[i][j]==9 || plateau[i][j]==10 && plateau[i][j]%2==couleur)
                {
                    roiColonne=j;
                    roiLigne=i;
                }
            }
        }
        for(int i = -1 ; i <= 1 ; i++)
        {
            for(int j = -1 ; j <= 1 ; j++)
            {
                if((i!=0 || j!=0) && coordonneesSurPlateau(roiLigne+i,roiColonne+j) && plateau[roiLigne+i][roiColonne+j]==0 && plateauCaseControleesEnnemi[roiLigne+i][roiColonne+j]==0)
                    return false;
            }
        }

        List<Case> pionAdapter = new ArrayList<>();
        int pionsauvegarde;
        int[][] caseControleesEnnemiTmp;
        for(int i = 0 ; i < plateau.length ; i++)
            for(int j = 0 ; j < plateau[i].length ; j++)
            {
                if(plateau[i][j]!=9 && plateau[i][j]!=10)
                {
                    pionsauvegarde = plateau[i][j];
                    plateau[i][j] = 20; // bloc
                    caseControleesEnnemiTmp = couleur == 0 ? actualisationCaseControlees(plateau, 1) : actualisationCaseControlees(plateau, 0);
                    if (!estEnEchec(plateau, caseControleesEnnemiTmp, couleur))
                        if (plateauCaseControleesAllie[i][j] == couleurControle)
                        {
                            plateau[i][j] = pionsauvegarde;
                            System.out.println(plateau[i][j]);
                            pionAdapter.addAll(quiPeutAccederALaCase(plateau, couleur, new Case(j, i)));
                            for(Case pion : pionAdapter)
                            {
                                int piece = plateau[pion.getLigne()][pion.getColonne()];
                                plateau[pion.getLigne()][pion.getColonne()]=0;
                                plateau[i][j]=piece;
                                if(!estEnEchec(plateau, caseControleesEnnemiTmp, couleur))
                                {
                                    plateau[pion.getLigne()][pion.getColonne()]=piece;
                                    plateau[i][j] = pionsauvegarde;
                                    return false;
                                }
                                plateau[pion.getLigne()][pion.getColonne()]=piece;
                                plateau[i][j] = pionsauvegarde;
                            }
                        }
                    plateau[i][j] = pionsauvegarde;
                }
            }
        return true;
    }

    /***
     *
     * @param plateau
     * @param couleur
     * @param emplacement
     *
     * Retourne les cases des pions qui on accès à la case emplacement
     */
    public static List<Case> quiPeutAccederALaCase(int[][] plateau, int couleur, Case emplacement)
    {
        List<Case> pionAdapter = new ArrayList<>();
        int colonne = emplacement.getColonne();
        int ligne = emplacement.getLigne();

        for(int i = 0 ; i < plateau.length ; i++)
        {
            for(int j = 0 ; j < plateau[i].length ; j++)
            {
                if(!vide(plateau, j, i) && plateau[i][j]%2==couleur && plateau[i][j]!=9 && plateau[i][j]!=10)
                {
                    int[][] accesPlateauPion = new int[8][8];
                    int pion = plateau[i][j];
                    if(pion <= 2)
                        accesPlateauPion = controleCasePion(plateau, accesPlateauPion, new Case(j,i), couleur);
                    else if(pion <= 4)
                        accesPlateauPion = controleCaseTour(plateau, accesPlateauPion, new Case(j,i), couleur);
                    else if(pion <= 6)
                        accesPlateauPion = controleCaseCavalier(accesPlateauPion, new Case(j,i), couleur);
                    else if(pion <= 8)
                        accesPlateauPion = controleCaseReine(plateau, accesPlateauPion, new Case(j,i), couleur);
                    else if(pion <= 10)
                        accesPlateauPion = controleCaseRoi(accesPlateauPion, new Case(j,i), couleur);
                    else
                        accesPlateauPion = controleCaseFou(plateau, accesPlateauPion, new Case(j,i), couleur);

                    if(accesPlateauPion[ligne][colonne]!=0) {
                        for(int a = 0 ; a < plateau.length ; a++){
                            for(int b = 0 ; b<plateau.length ; b++)
                                System.out.print(accesPlateauPion[a][b]);
                            System.out.println();
                        }
                        pionAdapter.add(new Case(j, i));
                    }
                    plateau[i][j]=pion;
                }
            }
        }

        return pionAdapter;
    }

    /***
     *
     * @param plateau
     * @param couleur
     * @param fin
     * @param caseControleesParEnnemi
     *
     * Regarde si le joueur peut faire le roque
     *
     */
   public static boolean roquePossible(int[][] plateau, int couleur, Case fin, int[][] caseControleesParEnnemi)
    {
        if(couleur==0 && (!roquePossibleBlanc[0] || (!roquePossibleBlanc[1] && !roquePossibleBlanc[2])))
            return false;
        else if (!roquePossibleNoir[0] || (!roquePossibleNoir[1] && !roquePossibleNoir[2]))
            return false;


        // Petit roque
        if(fin.getColonne()==6) {
            if (couleur == 0 && roquePossibleBlanc[2] && plateau[7][5] == 0 && plateau[7][6] == 0 && caseControleesParEnnemi[7][6] == 0)
            {
                plateau[7][7]=0;
                plateau[7][5]=4;
                return true;
            }
            if (couleur == 1 && roquePossibleNoir[1] && plateau[0][5] == 0 && plateau[0][6] == 0 && caseControleesParEnnemi[0][6] == 0)
            {
                plateau[0][7]=0;
                plateau[0][5]=3;
                return true;
            }
        }
        else if(fin.getColonne()==2) {
            if (couleur == 0 && roquePossibleBlanc[1] && plateau[7][1] == 0 && plateau[7][2] == 0 && plateau[7][3] == 0 && caseControleesParEnnemi[7][2]==0)
            {
                plateau[7][0]=0;
                plateau[7][3]=4;
                return true;
            }
            if (couleur == 1 && roquePossibleNoir[2] && plateau[0][1] == 0 && plateau[0][2] == 0 && plateau[0][3] == 0 && caseControleesParEnnemi[0][2]==0)
            {
                plateau[0][0]=0;
                plateau[0][3]=3;
                return true;
            }
        }
        return false;
    }

    public static int[][] copie(int[][] plateau){
        int[][] copie = new int[8][8];
        for(int i = 0 ; i < plateau.length ; i++){
            for(int j = 0 ; j < plateau.length ; j++)
                copie[i][j]=plateau[i][j];
        }
        return copie;
    }

    public static int retournerPion(int[][] plateau, Case piece)
    {
        return plateau[piece.getLigne()][piece.getColonne()];
    }
    public static boolean vide(int[][] plateau, Case debut)
    {
        return plateau[debut.getLigne()][debut.getColonne()]==0;
    }
    public static boolean vide(int[][] plateau, int colonne, int ligne)
    {
        return plateau[ligne][colonne]==0;
    }
    public static int couleur(int[][] plateau, Case debut)
    {
        return plateau[debut.getLigne()][debut.getColonne()]%2;
    }
    public static boolean debutFinMemeCouleur(int[][] plateau, Case debut, Case fin)
    {
        return !vide(plateau, fin) && couleur(plateau, fin)==couleur(plateau, debut);
    }
    public static boolean coordonneesSurPlateau(Case saisie)
    {
        return saisie.getLigne() >= 0 && saisie.getLigne() < 8 && saisie.getColonne() >= 0 && saisie.getColonne() < 8;
    }
    public static boolean coordonneesSurPlateau(int x, int y)
    {
        return x >= 0 && x < 8 && y >= 0 && y < 8;
    }
}